create procedure myProc()
  BEGIN
    SELECT SUM(qty * unitPrice) as Total FROM OrderDetail GROUP BY orderId;
  end;

